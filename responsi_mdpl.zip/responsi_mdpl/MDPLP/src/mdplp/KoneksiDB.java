/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mdplp;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author NITRO
 */
public class KoneksiDB {
        //membuat variabel bertipe connection
    private static Connection koneksi;
    
    public static Connection getKoneksi(){
        //method ini untuk membuat koneksi ke mysql
        if(koneksi == null){
            
            try{
                String url = "jdbc:mysql://localhost:3306/sia_mdpl";
                String username = "root";
                String password = "";
                
//                DriverManager.registerDriver(new com.sql.jdbc.Driver());
                
                koneksi = (Connection) DriverManager.getConnection(url,username,password);
            }
            catch(SQLException e){
                System.out.println("Gagal Membuat Koneksi");
            }
        }
        return koneksi;
    }
    
}
