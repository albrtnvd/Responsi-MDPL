-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 17, 2021 at 02:04 PM
-- Server version: 10.4.18-MariaDB
-- PHP Version: 8.0.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sia_mdpl`
--

-- --------------------------------------------------------

--
-- Table structure for table `tb_absensi`
--

CREATE TABLE `tb_absensi` (
  `id_absensi` int(11) NOT NULL,
  `id_dosen` varchar(15) NOT NULL,
  `id_mahasiwa` varchar(20) NOT NULL,
  `id_mk` varchar(20) NOT NULL,
  `jam_masuk` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `tb_administrasi`
--

CREATE TABLE `tb_administrasi` (
  `id` int(11) NOT NULL,
  `status_pembayaran` varchar(10) NOT NULL,
  `tahun_ajaran` varchar(20) NOT NULL,
  `semester` int(11) NOT NULL,
  `jenis_pembayaran` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `tb_dosen`
--

CREATE TABLE `tb_dosen` (
  `id_dosen` int(11) NOT NULL,
  `nama_dosen` varchar(200) NOT NULL,
  `nip` varchar(15) NOT NULL,
  `jenis_kelamin` varchar(20) NOT NULL,
  `alamat` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tb_dosen`
--

INSERT INTO `tb_dosen` (`id_dosen`, `nama_dosen`, `nip`, `jenis_kelamin`, `alamat`) VALUES
(1, 'Albertus Novvidi', '5200411443', 'Laki-Laki', 'Sorong'),
(2, 'Ahmat Alfatah', '5200411442', 'Laki-Laki', 'FakFak');

-- --------------------------------------------------------

--
-- Table structure for table `tb_jadwal`
--

CREATE TABLE `tb_jadwal` (
  `id` int(11) NOT NULL,
  `ruang_kelas` varchar(500) NOT NULL,
  `date_time` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `tb_mahasiswa`
--

CREATE TABLE `tb_mahasiswa` (
  `id_mahasiswa` int(11) NOT NULL,
  `npm` varchar(20) NOT NULL,
  `nama` varchar(200) NOT NULL,
  `jenis_kelamin` varchar(20) NOT NULL,
  `prodi` varchar(100) NOT NULL,
  `alamat` varchar(300) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tb_mahasiswa`
--

INSERT INTO `tb_mahasiswa` (`id_mahasiswa`, `npm`, `nama`, `jenis_kelamin`, `prodi`, `alamat`) VALUES
(3, '5200411432', 'Fulgensius Nemesio Manfret Nitu', 'Laki-Laki', 'Informatika', 'Nusa Tenggara Timur'),
(4, '5200411442', 'Ahmat Alfatah', 'Laki-Laki', 'Informatika', 'Jawa Tengah'),
(5, '5200411443', 'Albertus Novvidi S.A', 'Laki-Laki', 'Informatika', 'Banten'),
(6, '5200411445', 'Gilang Wisnu Aji Nugraha', 'Laki-Laki', 'Informatika', 'Jawa Tengah');

-- --------------------------------------------------------

--
-- Table structure for table `tb_matkul`
--

CREATE TABLE `tb_matkul` (
  `id_mk` int(11) NOT NULL,
  `nama_matkul` varchar(50) NOT NULL,
  `kode_mk` varchar(20) NOT NULL,
  `sks` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tb_absensi`
--
ALTER TABLE `tb_absensi`
  ADD PRIMARY KEY (`id_absensi`),
  ADD UNIQUE KEY `id_mahasiwa` (`id_mahasiwa`),
  ADD UNIQUE KEY `id_mk` (`id_mk`),
  ADD KEY `nip` (`id_dosen`),
  ADD KEY `npm` (`id_mahasiwa`),
  ADD KEY `kode_mk` (`id_mk`),
  ADD KEY `id_dosen_2` (`id_dosen`),
  ADD KEY `id_mahasiwa_2` (`id_mahasiwa`),
  ADD KEY `id_mk_2` (`id_mk`),
  ADD KEY `id_dosen_3` (`id_dosen`),
  ADD KEY `id_mahasiwa_3` (`id_mahasiwa`),
  ADD KEY `id_mk_3` (`id_mk`);

--
-- Indexes for table `tb_dosen`
--
ALTER TABLE `tb_dosen`
  ADD PRIMARY KEY (`id_dosen`);

--
-- Indexes for table `tb_mahasiswa`
--
ALTER TABLE `tb_mahasiswa`
  ADD PRIMARY KEY (`id_mahasiswa`);

--
-- Indexes for table `tb_matkul`
--
ALTER TABLE `tb_matkul`
  ADD PRIMARY KEY (`id_mk`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tb_dosen`
--
ALTER TABLE `tb_dosen`
  MODIFY `id_dosen` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tb_mahasiswa`
--
ALTER TABLE `tb_mahasiswa`
  MODIFY `id_mahasiswa` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
